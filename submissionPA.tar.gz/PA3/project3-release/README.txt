Names: Emir Sahbegovic, Chase Anderson

Instructions to compile and use:
1. First run "make" in the project3-release directory. This should create an executable called virtmem.
2. Run "./virtmem npages nframes (rand|fifo|clean) (scan|sort|focus)". Npages is the amount of pages, nframes is the amount of frames, select one of three
   replacement algorithms by using rand, fifo, or clean (our custom algorithm), and finally select one of three programs by using scan, sort, or focus.
